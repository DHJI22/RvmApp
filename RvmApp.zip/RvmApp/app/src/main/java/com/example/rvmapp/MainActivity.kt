package com.example.rvmapp

import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.rvmapp.databinding.ActivityMainBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var processor: RvmProcessor? = null
    private var busy = false

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) startProcessing(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPick.setOnClickListener {
            if (!busy) pickVideo.launch("video/*")
        }
    }

    private fun startProcessing(uri: Uri) {
        val bgColor = if (binding.rbGreen.isChecked) 0xFF00FF00.toInt() else 0xFF000000.toInt()

        busy = true
        binding.btnPick.isEnabled = false
        binding.rbGreen.isEnabled = false
        binding.rbBlack.isEnabled = false
        binding.progressBar.isIndeterminate = true
        binding.tvStatus.text = "Загрузка модели..."
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val proc = RvmProcessor(applicationContext)
        processor = proc

        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.Default) {
                    proc.process(uri, bgColor) { current, total ->
                        runOnUiThread {
                            binding.progressBar.isIndeterminate = false
                            binding.progressBar.max = total
                            binding.progressBar.progress = current
                            binding.tvStatus.text = "Обработка кадра $current из $total..."
                        }
                    }
                }
                binding.progressBar.isIndeterminate = false
                binding.tvStatus.text = "Готово! Сохранено: $result"
                Toast.makeText(this@MainActivity, "Готово", Toast.LENGTH_LONG).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                binding.progressBar.isIndeterminate = false
                binding.tvStatus.text = "Ошибка: ${e.javaClass.simpleName}: ${e.message}"
            } finally {
                busy = false
                binding.btnPick.isEnabled = true
                binding.rbGreen.isEnabled = true
                binding.rbBlack.isEnabled = true
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                proc.close()
                processor = null
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        processor?.close()
    }
}
