package com.example.rvmapp

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.Surface
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class RvmProcessor(private val context: Context) {

    companion object {
        private const val MODEL_NAME = "rvm_mobilenetv3_fp32.onnx"
        private const val TARGET_SHORT_SIDE = 512
        private const val MAX_FPS = 30f
        private const val DOWNSAMPLE_RATIO = 0.5f
        private const val USE_NNAPI = true
    }

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var session: OrtSession? = null
    private var usingNnapi = false

    // Рекуррентные состояния r1..r4
    private var initStates: List<OnnxTensor>? = null
    private var prevResult: OrtSession.Result? = null
    private var ratioTensor: OnnxTensor? = null
    private var srcBuffer: FloatBuffer? = null

    // ---------------------------------------------------------------- сессия

    private fun createSession(tryNnapi: Boolean): OrtSession {
        val modelBytes = context.assets.open(MODEL_NAME).use { it.readBytes() }

        if (tryNnapi) {
            try {
                val opts = OrtSession.SessionOptions()
                opts.setIntraOpNumThreads(4)
                opts.addNnapi()
                val s = env.createSession(modelBytes, opts)
                usingNnapi = true
                return s
            } catch (t: Throwable) {
                // любые проблемы драйвера -> откат на CPU
            }
        }

        val cpuOpts = OrtSession.SessionOptions()
        cpuOpts.setIntraOpNumThreads(4)
        usingNnapi = false
        return env.createSession(modelBytes, cpuOpts)
    }

    private fun directFloatBuffer(size: Int): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private fun resetState() {
        closeState()
        val zeros = ArrayList<OnnxTensor>()
        for (i in 0 until 4) {
            val fb = directFloatBuffer(1)
            fb.put(0, 0f)
            zeros.add(OnnxTensor.createTensor(env, fb, longArrayOf(1, 1, 1, 1)))
        }
        initStates = zeros

        val rb = directFloatBuffer(1)
        rb.put(0, DOWNSAMPLE_RATIO)
        ratioTensor = OnnxTensor.createTensor(env, rb, longArrayOf(1))
    }

    private fun closeState() {
        try { prevResult?.close() } catch (e: Exception) { }
        prevResult = null
        initStates?.forEach { try { it.close() } catch (e: Exception) { } }
        initStates = null
        try { ratioTensor?.close() } catch (e: Exception) { }
        ratioTensor = null
    }

    private fun currentStates(): List<OnnxTensor> {
        val r = prevResult
        return if (r != null) {
            listOf("r1o", "r2o", "r3o", "r4o").map { r.get(it).get() as OnnxTensor }
        } else {
            initStates!!
        }
    }

    // ---------------------------------------------------------------- инференс

    /** Возвращает маску pha (h*w значений 0..1). */
    private fun infer(px: IntArray, w: Int, h: Int): FloatArray {
        return try {
            runModel(px, w, h)
        } catch (e: Exception) {
            if (usingNnapi && prevResult == null) {
                // NNAPI упал на первом кадре -> пересоздаём сессию на CPU
                try { session?.close() } catch (x: Exception) { }
                session = createSession(false)
                runModel(px, w, h)
            } else {
                throw e
            }
        }
    }

    private fun runModel(px: IntArray, w: Int, h: Int): FloatArray {
        val plane = w * h
        val buf = srcBuffer!!
        for (i in 0 until plane) {
            val p = px[i]
            buf.put(i, ((p shr 16) and 0xFF) / 255f)
            buf.put(plane + i, ((p shr 8) and 0xFF) / 255f)
            buf.put(2 * plane + i, (p and 0xFF) / 255f)
        }
        buf.rewind()

        val srcTensor = OnnxTensor.createTensor(env, buf, longArrayOf(1, 3, h.toLong(), w.toLong()))
        try {
            val st = currentStates()
            val inputs = mapOf(
                "src" to srcTensor,
                "r1i" to st[0],
                "r2i" to st[1],
                "r3i" to st[2],
                "r4i" to st[3],
                "downsample_ratio" to ratioTensor!!
            )
            val result = session!!.run(inputs)

            // Старые состояния больше не нужны
            prevResult?.close()
            initStates?.forEach { it.close() }
            initStates = null
            prevResult = result

            val pha = result.get("pha").get() as OnnxTensor
            val fb = pha.floatBuffer
            fb.rewind()
            val out = FloatArray(plane)
            fb.get(out)
            return out
        } finally {
            srcTensor.close()
        }
    }

    // ---------------------------------------------------------------- видео

    private fun readFps(uri: Uri): Float {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                    return try {
                        f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat()
                    } catch (e: Exception) {
                        f.getFloat(MediaFormat.KEY_FRAME_RATE)
                    }
                }
            }
        } catch (e: Exception) {
            // игнорируем, вернём 30
        } finally {
            ex.release()
        }
        return 30f
    }

    private fun align16(v: Float): Int = max(16, (v / 16f).roundToInt() * 16)

    /**
     * Обрабатывает видео и возвращает текстовый путь сохранённого файла.
     * Звук в результат не переносится.
     */
    suspend fun process(videoUri: Uri, bgColor: Int, onProgress: (Int, Int) -> Unit): String {
        val fps = readFps(videoUri).coerceIn(1f, MAX_FPS)
        val retriever = MediaMetadataRetriever()
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        var muxerStarted = false
        val tmpFile = File(context.cacheDir, "rvm_tmp.mp4")
        if (tmpFile.exists()) tmpFile.delete()

        try {
            session = createSession(USE_NNAPI)
            resetState()

            retriever.setDataSource(context, videoUri)
            val durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L

            val first = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: throw IllegalStateException("Не удалось прочитать видео")
            val srcW = first.width
            val srcH = first.height
            first.recycle()

            val scale = min(1f, TARGET_SHORT_SIDE.toFloat() / min(srcW, srcH).toFloat())
            val w = align16(srcW * scale)
            val h = align16(srcH * scale)
            val total = max(1, (durationMs / 1000f * fps).toInt())

            srcBuffer = directFloatBuffer(3 * w * h)

            // ---- кодировщик H.264
            val bitrate = (w.toDouble() * h * fps * 0.15).toInt().coerceIn(2_000_000, 12_000_000)
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
            format.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps.roundToInt())
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)

            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = enc.createInputSurface()
            inputSurface = surface
            enc.start()

            val mux = MediaMuxer(tmpFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux

            var trackIndex = -1
            var outCount = 0L
            val info = MediaCodec.BufferInfo()

            // Забирает готовые данные из кодировщика и пишет в muxer.
            // Время кадров выставляем сами (по счётчику), так как при рисовании
            // на Surface системное время не совпадает с временем видео.
            fun drain(endOfStream: Boolean) {
                var idleLoops = 0
                while (true) {
                    val idx = enc.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!endOfStream) return
                        idleLoops++
                        if (idleLoops > 500) return
                    } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        trackIndex = mux.addTrack(enc.outputFormat)
                        mux.start()
                        muxerStarted = true
                    } else if (idx >= 0) {
                        val data = enc.getOutputBuffer(idx)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            info.size = 0
                        }
                        if (data != null && info.size > 0 && muxerStarted) {
                            data.position(info.offset)
                            data.limit(info.offset + info.size)
                            info.presentationTimeUs = (outCount * 1_000_000.0 / fps).toLong()
                            outCount++
                            mux.writeSampleData(trackIndex, data, info)
                        }
                        enc.releaseOutputBuffer(idx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            // ---- главный цикл по кадрам
            val bgR = (bgColor shr 16) and 0xFF
            val bgG = (bgColor shr 8) and 0xFF
            val bgB = bgColor and 0xFF
            val px = IntArray(w * h)
            val outBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

            for (i in 0 until total) {
                currentCoroutineContext().ensureActive()

                val timeUs = (i * 1_000_000.0 / fps).toLong()
                val raw = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                if (raw == null) {
                    onProgress(i + 1, total)
                    continue
                }
                val scaled = Bitmap.createScaledBitmap(raw, w, h, true)
                if (scaled !== raw) raw.recycle()
                scaled.getPixels(px, 0, w, 0, 0, w, h)
                scaled.recycle()

                val pha = infer(px, w, h)

                // Композитинг: кадр * маска + цвет фона * (1 - маска)
                for (k in 0 until w * h) {
                    val a = pha[k].coerceIn(0f, 1f)
                    val p = px[k]
                    val r = (((p shr 16) and 0xFF) * a + bgR * (1f - a)).toInt()
                    val g = (((p shr 8) and 0xFF) * a + bgG * (1f - a)).toInt()
                    val b = ((p and 0xFF) * a + bgB * (1f - a)).toInt()
                    px[k] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
                outBitmap.setPixels(px, 0, w, 0, 0, w, h)

                val canvas = surface.lockCanvas(null)
                canvas.drawBitmap(outBitmap, 0f, 0f, null)
                surface.unlockCanvasAndPost(canvas)

                drain(false)
                onProgress(i + 1, total)
            }
            outBitmap.recycle()

            // ---- завершение записи
            enc.signalEndOfInputStream()
            drain(true)

            enc.stop()
            enc.release()
            encoder = null
            surface.release()
            inputSurface = null
            if (muxerStarted) mux.stop()
            muxerStarted = false
            mux.release()
            muxer = null

            return saveToMovies(tmpFile)
        } finally {
            try { retriever.release() } catch (e: Exception) { }
            try { encoder?.stop() } catch (e: Exception) { }
            try { encoder?.release() } catch (e: Exception) { }
            try { inputSurface?.release() } catch (e: Exception) { }
            try { if (muxerStarted) muxer?.stop() } catch (e: Exception) { }
            try { muxer?.release() } catch (e: Exception) { }
            closeState()
            tmpFile.delete()
        }
    }

    // ---------------------------------------------------------------- сохранение

    private fun saveToMovies(tmp: File): String {
        val name = "RVM_${System.currentTimeMillis()}.mp4"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/RVM")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Не удалось создать файл в MediaStore")
            resolver.openOutputStream(uri)!!.use { out ->
                tmp.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return "Movies/RVM/$name"
        } else {
            // Android 8/9: папка приложения, чтобы не требовать разрешений
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                ?: throw IllegalStateException("Нет доступа к хранилищу")
            dir.mkdirs()
            val dest = File(dir, name)
            tmp.copyTo(dest, overwrite = true)
            return dest.absolutePath
        }
    }

    fun close() {
        closeState()
        try { session?.close() } catch (e: Exception) { }
        session = null
    }
}
